'use strict';
module.exports = (sequelize, DataTypes) => {
  const cd_blog_article = sequelize.define('cd_blog_article', {
    title: DataTypes.STRING,
    type: DataTypes.STRING,
    author: DataTypes.STRING,
    videourl: DataTypes.STRING,
    thumbnail: DataTypes.STRING,
    banner: DataTypes.STRING,
    metadesc: DataTypes.TEXT,
    sortdesc: DataTypes.TEXT,
    description: DataTypes.TEXT,
    slug: DataTypes.STRING,
    keyword: DataTypes.STRING,
  }, {});
  cd_blog_article.associate = function(models) {
    // associations can be defined here
  };
  return cd_blog_article;
};