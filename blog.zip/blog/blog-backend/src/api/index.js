import express from 'express';
import { authRouter } from './resources/auth'
import { articleRouter } from './resources/article'
export const restRouter = express.Router();
restRouter.use('/auth', authRouter);
restRouter.use('/article', articleRouter);







