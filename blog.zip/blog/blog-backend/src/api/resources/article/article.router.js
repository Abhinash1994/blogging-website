import express from "express";
import articleController from "./article.controller";
// import { localStrategy , jwtStrategy} from '../../../middleware/strategy';
// import { sanitize } from '../../../middleware/sanitizer';
// import { validateBody, schemas } from '../../../middleware/validator';
import upload from "../../../awsbucket";

export const articleRouter = express.Router();
articleRouter
  .route("/create")
  .post(
    upload.fields([{ name: "thumbnail" }, { name: "banner" }]),
    articleController.create
  );
articleRouter.route("/list").get(articleController.getAllList);
articleRouter.route("/list-by-id").post(articleController.getAllListById);
articleRouter.route("/slug").post(articleController.getBlogDetail);
