import { db } from "../../../models";

export default {
  async create(req, res, next) {
    let {
      id,
      title,
      type,
      author,
      videourl,
      thumbnail,
      banner,
      metadesc,
      sortdesc,
      description,
      keyword,
      slug,
    } = req.body;
    db.cd_blog_article
      .findOne({
        where: { id: id || null },
      })
      .then((data) => {
        if (data) {
          return db.cd_blog_article.update(
            {
              title: title ? title : data.title,
              type: type ? type : data.type,
              author: author ? author : data.author,
              videourl: videourl ? videourl : data.videourl,
              thumbnail: req.files.thumbnail
                ? "/" + req.files.thumbnail[0].originalname
                : data.thumbnail,
              banner: req.files.banner
                ? "/" + req.files.banner[0].originalname
                : data.banner,
              metadesc: metadesc ? metadesc : data.metadesc,
              sortdesc: sortdesc ? sortdesc : data.metadesc,
              description: description ? description : data.description,
              keyword: keyword ? keyword : data.keyword,
              slug: slug ? slug : data.slug,
            },
            { where: { id: id } }
          );
        } else {
          return db.cd_blog_article.create({
            title: title,
            type: type,
            author: author,
            videourl: videourl,
            thumbnail: req.files.thumbnail
              ? "/" + req.files.thumbnail[0].originalname
              : null,
            banner: req.files.banner
              ? "/" + req.files.banner[0].originalname
              : null,
            metadesc: metadesc,
            sortdesc: sortdesc,
            description: description,
            keyword: keyword,
            slug: slug,
          });
        }
      })
      .then((success) => {
        res.status(200).json({ success: true, msg: "One article is added" });
      })
      .catch((err) => {
        console.log(err);
        next(err);
      });
  },

  async getAllList(req, res, next) {
    db.cd_blog_article
      .findAll()
      .then((list) => {
        if (list) {
          return res.status(200).json({ success: true, list });
        } else
          res.status(500).json({ success: false, message: "No data Found" });
      })
      .catch((err) => {
        console.log(err);
        next(err);
      });
  },

  async getAllListById(req, res, next) {
    db.cd_blog_article
      .findOne({
        where: { id: req.body.id },
      })
      .then((list) => {
        if (list) {
          return res.status(200).json({ success: true, data: list });
        } else
          res.status(500).json({ success: false, message: "No data Found" });
      })
      .catch((err) => {
        console.log(err);
        next(err);
      });
  },
  async getBlogDetail(req, res, next) {
    db.cd_blog_article
      .findOne({
        where: { slug: req.body.slug },
      })
      .then((list) => {
        if (list) {
          return res.status(200).json({ success: true, data: list });
        } else
          res.status(500).json({ success: false, message: "No data Found" });
      })
      .catch((err) => {
        console.log(err);
        next(err);
      });
  },
};
