npm install
npm run sequelize db:migrate

Requirement
Nodejs install,
sequelize install
mysql,
