'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable('cd_blog_articles', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      title: {
        type: Sequelize.STRING
      },
      type: {
        type: Sequelize.STRING
      },
      author: {
        type: Sequelize.STRING
      },
      metadesc: {
        type: Sequelize.TEXT
      },
      sortdesc: {
        type: Sequelize.TEXT
      },
      description: {
        type: Sequelize.TEXT
      },
      videourl: {
        type: Sequelize.STRING
      },
      thumbnail: {
        type: Sequelize.STRING
      },
      banner: {
        type: Sequelize.STRING
      },
      keyword: {
        type: Sequelize.TEXT
      },
      slug: {
        type: Sequelize.TEXT
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable('cd_blog_articles');
  }
};