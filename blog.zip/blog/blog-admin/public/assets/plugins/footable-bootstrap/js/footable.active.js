$(document).ready(function () {
    "use strict"; // Start of use strict
    // Footable example 1
    $('#example1').footable();

    // Footable example 2
    $('#example2').footable();
});