import React, { Component } from 'react';
import './App.css';
import Admin from './components/admin';
// import Web from './components/web';
// import Auth from './components/auth';
import NoMatch from './components/nomatch';
import { Switch, Route, BrowserRouter } from 'react-router-dom';

export default class App extends Component {
	render() {
		return (
			<div className="App">
				<BrowserRouter>
					<Switch>
						<Route path='/admin' component={Admin} />
						<Route component={NoMatch} />
					</Switch>
				</BrowserRouter>
			</div>
		);
	}
}

