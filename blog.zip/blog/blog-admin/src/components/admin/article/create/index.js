import React, { Component } from 'react'
import { Grid, Paper, Button } from '@material-ui/core/';
import RichTextEditor from '../../../RichTextEditor';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import API from '../../../api';

export default class Create extends Component {
    constructor(props) {
        super(props);
        this.state = {
            content: ``, type: '', title: '',metadesc:'', sortdesc: '', author: '', videourl: '', thumbnail: '', banner:'', slug: '', keyword: '',
        }
    }
    // convert slug
    convertToSlug(text) {
        return text.toString().toLowerCase()
            .replace(/\s+/g, '-')           // Replace spaces with -
            .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
            .replace(/\-\-+/g, '-')         // Replace multiple - with single -
            .replace(/^-+/, '')             // Trim - from start of text
            .replace(/-+$/, '');            // Trim - from end of text
    }
    handleChangeEvent(e) {
        this.setState({ [e.target.name]: e.target.value })
    }
    handleContentChange = contentHtml => {
        this.setState({
            content: contentHtml
        });
    };

    onChangeBannerFile(e) {
        this.setState({ banner: event.target.files[0] });
    };

    onChangeIconFile(e) {
        this.setState({ thumbnail: event.target.files[0] });
    };
    handleSubmit(event) {
        event.preventDefault();
        let slug = this.convertToSlug(this.state.title)
        let { type, title, author, videourl,metadesc, sortdesc, thumbnail, banner, content, keyword } = this.state;

        const formData = new FormData();
        formData.append('type', type);
        formData.append('title', title);
        formData.append('author', author);
        formData.append('videourl', videourl);
        formData.append('thumbnail', thumbnail);
        formData.append('banner', banner);
        formData.append('metadesc', metadesc);
        formData.append('sortdesc', sortdesc);
        formData.append('description', content);
        formData.append('keyword', keyword);
        formData.append('slug', slug);
        
        const config = {     
            headers: { 'content-type': 'multipart/form-data' }
        }
        new API().getHttpClient().post('/article/create',formData, config).then((res) => {
            if (res) {
                toast.success("successfully updated");
            }
        })
            .catch(error => {
                console.log(error)
            })
    }


    render() {
        return (
            <div>
                <Paper style={{ background: '#eaeaea' }}>
                    <Grid container spacing={2}>
                        <Grid item md={2}>
                            <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Type : </h1>
                            <select className="form-control" name="type" value={this.state.type} onChange={(e) => this.handleChangeEvent(e)} >
                                <option value="select">Select an topic</option>
                                <option value="javascript">Javascript</option>
                                <option value="reactjs">Reactjs</option>
                                <option value="redux">Redux</option>
                                <option value="nodejs">Nodejs</option>
                                <option value="aws">AWS</option>
                                <option value="database">Mysql/Sequelize</option>
                            </select>
                        </Grid>
                        <Grid item md={3}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Title : </h1>
                                <input type="text" class="form-control" placeholder="title" name="title" value={this.state.title} onChange={(e) => this.handleChangeEvent(e)} />
                            </div>
                        </Grid>
                        <Grid item md={2}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Meta descriptiion </h1>
                                <textarea className="form-control" rows="3" name="metadesc" value={this.state.metadesc} onChange={(e) => this.handleChangeEvent(e)}></textarea>
                            </div>
                        </Grid>
                        <Grid item md={2}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Author : </h1>
                                <input type="text" class="form-control" placeholder="author name" name="author" value={this.state.author} onChange={(e) => this.handleChangeEvent(e)} />
                            </div>
                        </Grid>
                        <Grid item md={3}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>video url : </h1>
                                <input type="text" class="form-control" name="videourl" value={this.state.videourl} onChange={(e) => this.handleChangeEvent(e)} />
                            </div>
                        </Grid>
                    </Grid>

                    {/* //2nd row */}

                    <Grid container spacing={2}>
                        <Grid item md={3}>
                            <div className="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Sort Description : </h1>
                                <textarea className="form-control" rows="3" name="sortdesc" value={this.state.sortdesc} onChange={(e) => this.handleChangeEvent(e)}></textarea>
                            </div>

                        </Grid>
                        <Grid item md={3}>
                            <div className="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>thumbnail : </h1>
                                <input type="file" className="form-control" name="thumbnail" onChange={(e) => this.onChangeIconFile(e)} />
                            </div>
                        </Grid>

                        <Grid item md={3}>
                            <div className="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Banner : </h1>
                                <input type="file" className="form-control" name="banner" onChange={(e) => this.onChangeBannerFile(e)} />
                            </div>
                        </Grid>
                        <Grid item md={3}>
                            <div className="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>keyword/Tags : </h1>
                                <textarea className="form-control" rows="3" name="keyword" value={this.state.keyword} onChange={(e) => this.handleChangeEvent(e)}></textarea>
                            </div>
                        </Grid>

                    </Grid>
                    {/* close */}


                    {/* 3nd row */}

                    <Grid container spacing={2}>
                        <Grid item md={12}>
                            <div className="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Post Write: </h1>
                                <RichTextEditor
                                    content={this.state.content}
                                    handleContentChange={this.handleContentChange}
                                    placeholder="insert text here..."
                                />
                            </div>
                        </Grid>
                    </Grid>
                    {/* close */}
                    <Button variant="contained" color="secondary" onClick={(e) => this.handleSubmit(e)}>
                        Submit
                    </Button>
                    <ToastContainer autoClose={1500} />

                </Paper>
            </div>
        )
    }
}
