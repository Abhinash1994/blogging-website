import React, { useEffect, useState } from 'react';
import { useHistory } from "react-router-dom";
import {
    Paper
} from '@material-ui/core/';
import API from '../../../api';

const List = () => {
    const history = useHistory()
    const [data, setData] = useState([]);

    const handleAddProduct = (e) => {
        e.preventDefault();
        history.push("/admin/article-create")
    }

    const handleEdit = (event, data) => {
        event.preventDefault();
        history.push({
            pathname: "/admin/article-edit",
            state: data
        })
    }

    useEffect(() => {
        new API().getHttpClient().get('/article/list').then((res) => {
            if (res) {
                setData(res.data.list);
            }
        })
            .catch(error => {
                console.log(error)
            })
    }, [])
    return (
        <div >

            {/* Page Head */}
            <div class="page-wrapper ">
                <div className="form-group row mt-4">
                    <div className="col-sm-3">
                        <button type="button" className="btn btn-labeled btn-success ml-2" onClick={handleAddProduct}>
                            <span className="btn-label"><i class="fas fa-check"></i></span>Add product
                         </button>
                    </div>
                </div>
                {/* Category Table */}
                <hr></hr>
                <Paper>
                    <div className="sub-heads mb-3 mt-4">
                        <div className="col-sm-5 text-head">
                            <h5>Showing existing product list</h5>
                        </div>
                    </div>
                    <div className="table-responsive">
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Banner</th>
                                    <th>Name </th>
                                    <th>Type </th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                {data.length === 0 ? <p>No data Found</p> :
                                    data.map((row, index) => (
                                        <tr key={index}>
                                            <td>{++index}</td>
                                            <td>
                                                <img src={`https://grociproduct.s3.ap-south-1.amazonaws.com/blogs${row.thumbnail}`} alt="banner" width="70" />
                                            </td>
                                            <td>{row.title}</td>
                                            <td>{row.type}</td>
                                            <td style={{ display: '-webkit-box' }}>
                                                <button variant="contained" className="actions-btn" onClick={(event) => handleEdit(event, row)}><span className="typcn typcn-edit"></span></button>
                                            </td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                    </div>
                </Paper>
            </div>
        </div>
    );
};

export default List;