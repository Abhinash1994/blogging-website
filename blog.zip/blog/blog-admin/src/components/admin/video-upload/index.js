import React, { Component } from 'react'
import { Grid, Paper, Button } from '@material-ui/core/';

import API from '../../api';
export default class Video extends Component {
    constructor(props) {
        super(props);
        this.state = {
            title: '', url: ''
        }
    }
    handleChangeEvent(e) {
        this.setState({ [e.target.name]: e.target.value })
    }

    handleSubmit(event) {
        event.preventDefault();
        new API().getHttpClient().post('/video/upload', {
            title: this.state.title,
            url: this.state.url
        }).then((res) => {
            console.log(res)
        })
        .catch(error => {
            console.log(error)
        })
    }


    render() {
        return (
            <div>
                <Paper style={{ background: '#eaeaea' }}>
                    <Grid container spacing={2}>

                        <Grid item md={3}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>Title : </h1>
                                <input type="text" class="form-control" placeholder="title" name="title" value={this.state.title} onChange={(e) => this.handleChangeEvent(e)} />
                            </div>
                        </Grid>
                        <Grid item md={4}>
                            <div class="form-group">
                                <h1 style={{ paddingTop: '10px', fontSize: '20px' }}>url </h1>
                                <textarea className="form-control" rows="3" name="url" value={this.state.url} onChange={(e) => this.handleChangeEvent(e)}></textarea>
                            </div>
                        </Grid>
                    </Grid>
                    <Button variant="contained" color="secondary" onClick={(e) => this.handleSubmit(e)}>
                        Submit
                    </Button>
                </Paper>
            </div>
        )
    }
}
