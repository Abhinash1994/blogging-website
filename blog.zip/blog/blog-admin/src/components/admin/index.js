import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom'
import Dashboard from './dashboard';
import Header from './header';
import Footer from './footer'
import SideBar from './sidebar';
import Video from '../admin/video-upload';
import ArticleCreate from './article/create';
import ArticleList from './article/list';
import Edit from './article/edit';

export default class Main extends Component {
  render() {
    const { match } = this.props;
    return (
      <main>
        <div className="wrapper">
          <Header />
          <div className="content-wrapper">
            <div className="main-content">
              <SideBar />
              <Switch>
                <Route exact path={[`${match.path}/dashboard`, `${match.path}`]} component={Dashboard} />
                <Route exact path={`${match.path}/article-create`} component={ArticleCreate} />
                <Route exact path={`${match.path}/article-list`} component={ArticleList} />
                <Route exact path={`${match.path}/article-edit`} component={Edit} />
                <Route exact path={`${match.path}/upload-video`} component={Video} />
              </Switch>
              <Footer />
            </div>
          </div>

        </div>


      </main>
    );
  }
}