import React, { Component } from 'react';
import './App.css';
import Web from './components/web';
import NoMatch from './components/nomatch';
import { Switch, Route, BrowserRouter } from 'react-router-dom';

export default class App extends Component {
	render() {
		return (
			<div className="App">
				<BrowserRouter>
					<Switch>
						<Route path='/' component={Web}/>
						<Route component={NoMatch} />	
					</Switch>
				</BrowserRouter>
			</div>
		);
	}
}

