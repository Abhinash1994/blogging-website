import axios from "axios";

const BASE_URL = "http://localhost:4000/api/";
export default class API {
  constructor(lang = "EN") {
    this.lang = lang;
  }
  getHttpClient(baseURL = `${BASE_URL}`) {
    this.client = axios.create({
      baseURL: baseURL,
      /* headers: headers */
    });
    return this.client;
  }
}
