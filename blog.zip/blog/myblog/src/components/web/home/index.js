import React, { Component } from "react";
import { Grid, Button, Paper } from "@material-ui/core/";
import { Link } from "react-router-dom";
import subscribe from "./subscribe.png";
import Loader from "react-loader";

import API from "../../api";
export default class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      width: window.innerWidth,
      loading: true,
    };
  }
  formatDate(date) {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;
    return [year, month, day].join("-");
  }
  componentDidMount() {
    new API()
      .getHttpClient()
      .get("/article/list")
      .then((res) => {
        this.setState({ loading: false, list: res.data.list });
      })
      .catch((error) => {
        console.log(error);
      });
  }
  componentWillMount() {
    window.addEventListener("resize", this.handleWindowSizeChange);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.handleWindowSizeChange);
  }
  handleWindowSizeChange = () => {
    this.setState({ width: window.innerWidth });
  };

  render() {
    let prop = this.state.list;
    console.log("", prop);
    const { width } = this.state;
    const isMobile = width <= 500;
    return (
      <div>
        <Grid container>
          <Grid
            className="own-subscriber"
            id="own-blog"
            item
            xs={12}
            sm={12}
            md={4}
            lg={5}
            xl={5}
          >
            <img
              src={subscribe}
              alt="Be your own boss"
              className="lazyloaded"
              data-was-processed="true"
            />
          </Grid>
          <Grid item xs={12} sm={12} md={8} lg={7} xl={7} id="own-blog">
            <div className="top-subscriber">
              <h1>Subscribe Now !</h1>
              <p>
                This blog solve your problem just you will send your question on
                these language. & join our email newsletter to receive a free
                blogging course & you will get easy solution of your Question.
              </p>
            </div>
            <div className="getsubscriber_email">
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                className="ck_email_address"
                id="ck_emailField"
              />
              <Button variant="contained" color="secondary">
                Subscribe
              </Button>
            </div>
          </Grid>
          {/* <Grid item xs={12} sm={12} md={12} lg={12} xl={12} className="blogsection sml_order">
                        <div className="iwtsectioninner_name">
                            <h2>Courses</h2>
                        </div>
                        <Grid container>
                            <Grid item lg={2} xl={2}></Grid>
                            <Grid item xs={12} sm={12} md={12} lg={8} xl={8}>
                                <Grid container>
                                    <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                                        <Paper>
                                            <Grid container>
                                                <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                                                    <div className="ak-image-blog">

                                                    </div>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6} lg={6} xl={6}></Grid>
                                            </Grid>
                                        </Paper>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6} xl={6}></Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={2} lg={2} xl={2}></Grid>
                        </Grid>
                    </Grid> */}
        </Grid>

        {/* show total blog */}
        <Grid container className="main_post_bk blogsection sml_order">
          <Grid
            item
            xs={12}
            sm={12}
            md={12}
            lg={12}
            xl={12}
            className="blog_sectioninner"
          >
            <h2>Recent Post</h2>
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
            <Grid container>
              <Grid item md={1} lg={2} xl={2}></Grid>
              <Grid
                item
                xs={12}
                sm={12}
                md={10}
                lg={8}
                xl={8}
                style={{ marginBottom: "4rem" }}
              >
                {this.state.loading ? (
                  <Loader />
                ) : (
                  <Grid container spacing={3}>
                    {prop && prop.length
                      ? prop.map((data, i) => (
                          <Grid
                            item
                            xs={12}
                            sm={12}
                            md={12}
                            lg={12}
                            xl={12}
                            key={i}
                          >
                            <Link
                              to={{
                                pathname: `/${data.type}/${data.slug}`,
                                state: data,
                              }}
                              style={{ textDecoration: "none" }}
                            >
                              <Paper className="paper">
                                <Grid container>
                                  <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
                                    <div className="ak-image-blog">
                                      <img
                                        src={
                                          "https://grociproduct.s3.ap-south-1.amazonaws.com/blogs" +
                                          data.thumbnail
                                        }
                                        alt={data.title}
                                      />
                                    </div>
                                  </Grid>
                                  <Grid
                                    item
                                    xs={8}
                                    sm={8}
                                    md={8}
                                    lg={8}
                                    xl={8}
                                    style={{ textAlign: "-webkit-auto" }}
                                  >
                                    <div className="ak_blog_title">
                                      <h1>{`${data.title.substring(
                                        0,
                                        50
                                      )}...`}</h1>
                                    </div>
                                    <div className="ak-description-blog">
                                      {isMobile ? (
                                        <p>
                                          {" "}
                                          {`${data.sortdesc.substring(
                                            0,
                                            150
                                          )}...`}
                                          <span style={{ color: "blue" }}>
                                            read more
                                          </span>
                                        </p>
                                      ) : (
                                        <p>
                                          {" "}
                                          {`${
                                            data && data.sortdesc
                                              ? data.sortdesc.substring(0, 550)
                                              : ""
                                          }...`}
                                          <span style={{ color: "blue" }}>
                                            read more
                                          </span>
                                        </p>
                                      )}
                                    </div>
                                    <div className="blogfooter">
                                      <ul>
                                        <li>
                                          {" "}
                                          <span className="entry-time">
                                            {this.formatDate(data.createdAt)}
                                          </span>{" "}
                                        </li>
                                        <li>
                                          {" "}
                                          <span> {data.author} </span>
                                        </li>
                                        <li>
                                          {" "}
                                          <span className="entry-comment">
                                            {" "}
                                            {data && data.comments
                                              ? data.comments.length
                                              : ""}{" "}
                                            Comment{" "}
                                          </span>
                                        </li>
                                      </ul>
                                    </div>
                                  </Grid>
                                </Grid>
                              </Paper>
                            </Link>
                          </Grid>
                        ))
                      : ""}
                  </Grid>
                )}
              </Grid>
              <Grid item xs={2} sm={2} md={1} lg={2} xl={2}></Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    );
  }
}
