import React, { Component } from 'react';
import { Modal } from '@material-ui/core/';
import { Link } from 'react-router-dom';

class NavPopUp extends Component {
    constructor(props) {
        super(props);
        this.state = { open: false, status: 0, loading: false }
    }

    handleOpen(e) {
        this.setState({ open: !this.state.open, loading: true })
    }

    handleClose(e) {
        this.setState({ open: !this.state.open })
    }
    render() {
        return (
            <div>
                <div className="list_dropdown">
                    <i className="material-icons" onClick={(e) => this.handleOpen()}>list</i>
                </div>
                <Modal
                    aria-labelledby="simple-modal-title"
                    aria-describedby="simple-modal-description"
                    open={this.state.open}
                >
                    <div className="modal-content">
                        <div className="modal-header_delete">
                            <span><i className="material-icons cross" onClick={(e) => this.handleClose(e)}>clear</i></span>
                            <ul onClick={(e) => this.handleOpen()}>
                                <li id="menu-item-297287" className="smllc-menu-desktop-new-articles menu-item menu-item-type-custom menu-item-object-custom menu-item-297287"><Link to="/"><span>Home</span></Link>
                                </li>
                                {/* <li id="menu-item-297287" className="smllc-menu-desktop-new-articles menu-item menu-item-type-custom menu-item-object-custom menu-item-297287"><Link to="/"><span>New Articles</span></Link>
                                </li> */}
                               
                                {/* <li id="menu-item-280890" className="menu-item menu-item-type-custom menu-item-object-custom menu-item-280890"><Link to={"/questions"}><span>Start a blog</span></Link>
                                </li> */}
                                
                                <li className="javascript"><Link to={"/search/javascript"}><span>Javascript</span></Link></li>
                                <li className="javascript"><Link to={"/search/reactjs"}><span>Reactjs</span></Link></li>
                                {/* <li className="javascript"><Link to={"/search/mongodb"}><span>MongoDb</span></Link></li> */}
                                <li className="javascript"><Link to={"/search/nodejs"}><span>Nodejs</span></Link></li>
                                <li id="menu-item-297306" className="menu-item menu-item-type-custom menu-item-object-custom menu-item-297306">
                                    <Link to={"/about"}><span>About</span></Link>
                                </li>
                                <li id="menu-item-297302" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-297302">
                                    <Link to={"/all/questions"}><span>Ask me Question</span></Link>
                                </li>
                                {/* <li className="javascript"><Link to={"/search/video"}><span>Tutorial Video</span></Link></li> */}
                            </ul>
                        </div>

                    </div>
                </Modal>
            </div>
        )
    }
}

export default NavPopUp;