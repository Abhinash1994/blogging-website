import React, { Component } from 'react'
import { Grid, Paper } from '@material-ui/core';
import { Link } from 'react-router-dom';
import Loader from 'react-loader'

import API from '../../api';
export default class Reactinfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [], width: window.innerWidth,
            loading: false
        }
    }
    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;
        return [year, month, day].join('-');
    }
    componentDidMount() {
        let url = window.location.href.split('/');
        var lastSegment = url.pop() || url.pop();
        new API().getHttpClient().post('/blog/course', { type: lastSegment }).then((res) => {
            this.setState({ loading: false, list: res.data });
        })
            .catch(error => {
                console.log(error)
            })
    }
    componentWillMount() {
        window.addEventListener('resize', this.handleWindowSizeChange);
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.handleWindowSizeChange);
    }
    handleWindowSizeChange = () => {
        this.setState({ width: window.innerWidth });
    };
    render() {
        let prop = this.state.list.data;
        const { width } = this.state;
        const isMobile = width <= 500;
        return (
            <div>

                <Grid container>
                    <Grid item lg={2} xl={3}></Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                        {prop ?
                            <Grid container>
                                <Grid item md={1} lg={2} xl={2}></Grid>
                                <Grid item xs={12} sm={12} md={10} lg={8} xl={8} style={{ marginBottom: '4rem', marginTop: '1rem' }}>
                                    {this.state.loading ? <Loader /> :
                                        <Grid container spacing={3}>
                                            {
                                                prop.map((data, i) => (
                                                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12} key={i}>
                                                        <Link to={{ pathname: `/${data.type}/${data.slug}`, state: data }} style={{ textDecoration: 'none' }}>
                                                            <Paper className="paper">
                                                                <Grid container>
                                                                    <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
                                                                        <div className="ak-image-blog">
                                                                            <img src={data.imgurl} alt={data.title} />
                                                                        </div>
                                                                    </Grid>
                                                                    <Grid item xs={8} sm={8} md={8} lg={8} xl={8} style={{ textAlign: '-webkit-auto' }}>
                                                                        <div className="ak_blog_title">
                                                                            <h1>{`${data.title.substring(0, 50)}...`}</h1>
                                                                        </div>
                                                                        <div className="ak-description-blog">
                                                                            {
                                                                                isMobile ? <p> {`${data.body.substring(0, 150)}...`}<span style={{ color: 'blue' }}>read more</span></p> : <p> {`${data.body.substring(0, 550)}...`}<span style={{ color: 'blue' }}>read more</span></p>
                                                                            }

                                                                        </div>
                                                                        <div className="blogfooter">
                                                                            <ul>
                                                                                <li> <span className="entry-time">{this.formatDate(data.createdAt)}</span> </li>
                                                                                <li> <span> {data.author} </span></li>
                                                                                <li>  <span className="entry-comment"> {data.comments.length} Comment </span></li>
                                                                            </ul>
                                                                        </div>
                                                                    </Grid>
                                                                </Grid>
                                                            </Paper>
                                                        </Link>
                                                    </Grid>
                                                ))
                                            }

                                        </Grid>
                                    }
                                </Grid>
                                <Grid item xs={2} sm={2} md={1} lg={2} xl={2}></Grid>
                            </Grid>
                            : <p>Loading... </p>}
                    </Grid>
                    <Grid item lg={2} xl={3}></Grid>
                </Grid>

            </div>
        )
    }
}
