import React, { Component } from 'react';
import { Grid, Paper, Button, ExpansionPanel, ExpansionPanelSummary, /* ExpansionPanelDetails */ } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Link } from 'react-router-dom'
import API from '../../api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default class Questionlist extends Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [], loading: true
        }
    }
    componentDidMount() {
        new API().getHttpClient().get('/question').then((res) => {
            if (res) {
                this.setState({ loading: false, list: res.data.sucess });
            }
        })
            .catch(error => {
                toast.error("error !!" + error)
            })
    }
    render() {
        return (
            <div>
                <Grid container>
                    <Grid item md={2} lg={2} xl={2}></Grid>
                    <Grid item xs={12} sm={12} md={8} lg={8} xl={8} >
                        <Paper className="main_question_header">
                            <div className="question-header">
                                <h2>All Questions</h2>
                                <div className="ak-question-add">
                                    <Link to="/questions"><Button variant="contained" color="primary">ADD Question </Button></Link>
                                </div>

                                {this.state.list.map((prop, index) => (
                                    <ExpansionPanel key={index} className="question_list_bk">
                                        <ExpansionPanelSummary
                                            expandIcon={<ExpandMoreIcon />}
                                            aria-controls="panel1a-content"
                                            id="panel1a-header"
                                            style={index%2 ? {background:'#fff'}:{background:'#f9f9f9'}}
                                        >   
                                        <h5>{prop.title}</h5>
                                        </ExpansionPanelSummary>
                                        {/* <ExpansionPanelDetails>
                                            <div className="question-desc">
                                                <p>{prop.description}</p>
                                            </div>
                                        </ExpansionPanelDetails> */}
                                    </ExpansionPanel>
                                ))}
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item  md={2} lg={2} xl={2}></Grid>
                </Grid>
                <ToastContainer autoClose={1500} />
            </div>
        )
    }
}
