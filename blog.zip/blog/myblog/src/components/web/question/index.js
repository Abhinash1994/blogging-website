import React, { Component } from 'react'
import { Grid, Paper, h6 } from '@material-ui/core';
import './question.css';
import API from '../../api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default class Questions extends Component {
    constructor(props) {
        super(props);
        this.state = {
            firstName:'',lastName:'',title:'',
            loading: true
        }
    }
    handleChange(e){
        this.setState({ [e.target.name]: e.target.value })
    }
    handleSubmit(e) {
        e.preventDefault();
        new API().getHttpClient().post('/question',{
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            title: this.state.title,
            // description: this.state.description
        }).then((res) => {
            if(res){
                window.location.href="/all/questions"
                toast.success(res.data.msg)
            }
        })
        .catch(error => {
            toast.error("error !!"+error)
        })
    }
    render() {
        return (
            <div>
                <Grid container>
                    <Grid item xs={1} sm={1} md={2} lg={2} xl={2}></Grid>
                    <Grid item xs={10} sm={10} md={7} lg={7} xl={7} style={{ margin: '3rem' }}>
                        <Paper>
                            <div className="question-header">
                                <h1>Put Your Questions</h1>
                                <form>
                                    <div className="form-group">
                                        <h6 >First Name </h6>
                                        <input type="text" className="form-control" placeholder="first name" name="firstName" value={this.state.firstName} onChange={(e)=>this.handleChange(e)}/>
                                    </div>
                                    <div className="form-group">
                                        <h6 >Last Name </h6>
                                        <input type="text" className="form-control" placeholder="last name" name="lastName"  value={this.state.lastName} onChange={(e)=>this.handleChange(e)}/>
                                    </div>
                                    <div className="form-group">
                                        <h6 >Questions</h6>
                                        <input type="text" className="form-control" name="title"  value={this.state.title} onChange={(e)=>this.handleChange(e)}/>
                                    </div>
                                    {/* <div className="form-group">
                                        <h6 >Description</h6>
                                        <textarea type="text" className="form-control" name="description"  value={this.state.description} onChange={(e)=>this.handleChange(e)}/>
                                    </div> */}
                                    <button type="submit" className="btn btn-primary" onClick={(e)=>this.handleSubmit(e)}>Submit</button><ToastContainer autoClose={1500} />
                                </form>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item xs={1} sm={1} md={2} lg={2} xl={2}></Grid>
                </Grid>
            </div>
        )
    }
}
