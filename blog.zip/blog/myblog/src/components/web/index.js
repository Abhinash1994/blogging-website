import React, { Component } from 'react';
import { Switch, Route } from 'react-router-dom';
import Home from './home';
import Header from './header';
import Footer from './footer';
import Blogdetail from './blog-detail';
import Question from './question';
import Questionlist from './question-list';
import Javascript from './javascript';
import Reactinfo from './reactjs';
import Nodeinfo from './nodejs';
import About from './about';
import NotFound from '../nomatch'
export default class Main extends Component {
  render() {
    return (
      <main>
        <div className="wrapper">
          <Header />
          <Switch>
            <Route exact path='/' component={Home} />
            <Route path='/questions' component={Question} />
            <Route path='/search/javascript' component={Javascript} />
            <Route path='/search/reactjs' component={Reactinfo} />
            <Route path='/search/nodejs' component={Nodeinfo} />
            <Route path='/all/questions' component={Questionlist} />
            <Route path='/:type/:slug' component={Blogdetail} />
            <Route path='/about' component={About} />
            <Route component={NotFound} />
          </Switch>
          <Footer />
        </div>
      </main>
    );
  }
}