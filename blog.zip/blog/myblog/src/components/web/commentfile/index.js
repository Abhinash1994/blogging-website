import React, { Component } from 'react'
import { Grid, Paper } from '@material-ui/core/';
import API from '../../api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
export default class CommentFile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isOpened: false, isLoaded: false, name: '', email: '', comment: '',
            getdata: [],
        }
    }
    handleChange(e) {
        this.setState({ [e.target.name]: e.target.value })
    }
    toggleBox(e) {
        this.setState({ isOpened: true });
    }
    validate = () => {
        let nameerror = '';
        let commenterror = '';
        if (!this.state.comment) {
            commenterror = "comment cannot be blank"
        }
        if (!this.state.name) {
            nameerror = 'Enter valid name'
        }
        if (nameerror || commenterror) {
            this.setState({ nameerror: nameerror, commenterror: commenterror })
            return false
        }
        return true
    }
    async handleleSubmit() {
        let array = [];
        array.push({ user: this.state.name, message: this.state.comment })
        const isValid = this.validate();
        if (isValid) {
            await new API().getHttpClient().post('/comment', {
                comments: array,
                _id: this.props.state._id

            }).then((res) => {
                if (res) {
                    this.setState({ isLoaded: true, isOpened: !this.state.isOpened })
                    window.location.reload();
                }
            })
                .catch(error => {
                    toast.error("error !!" + error)
                })
        }
    }
    async componentDidMount() {
        this.setState({ isLoaded: false })
        await new API().getHttpClient().get('/blog/' + this.props.state._id).then((res) => {
            if (res) {
                this.setState({ isLoaded: true, getdata: res.data.data })
            }
        })
            .catch(error => {
                toast.error("error !!" + error)
            })
    }
    render() {
        let prop = this.props.state.comments;
        return (
            <div>
                <Paper>
                    <div className="ak-comments-number">
                        <h5>{prop.length} comments</h5>
                    </div>
                    <Grid container>
                        <Grid item xs={1} sm={1} md={2} xl={2} lg={2}>
                            <div className="commentbox">
                                <i className="material-icons person">
                                    person
                            </i>
                            </div>
                        </Grid>
                        <Grid item xs={10} sm={10} md={10} xl={10} lg={10}>
                            <div className="right">
                                <div className="tcm-post-input-container thrive-comments">
                                    <textarea className={this.state.commenterror ? "form-control is-invalid" : 'form-control'} id="tcm-post-content" name="comment" placeholder="Enter your comment..." onClick={(e) => this.toggleBox(e)} value={this.state.comment} onChange={(e) => this.handleChange(e)}></textarea>
                                    {this.state.commenterror ? <div className="invalid-feedback text-left" style={{ color: 'red' }}>{this.state.commenterror}</div> : null}
                                </div>
                                <div className="tcm-comment-additional-fields" style={this.state.isOpened ? { display: 'block' } : { display: 'none' }}>
                                    <div className="inner clear-this">
                                        <div className="thrive-comments">
                                            <p>Comment as a guest:</p>
                                            <input id="tcm-guest-name" className={this.state.nameerror ? "form-control is-invalid" : 'form-control'} type="text" name="name" placeholder="Name" onChange={(e) => this.handleChange(e)} value={this.state.name} />
                                            {this.state.nameerror ? <div className="invalid-feedback text-left" style={{ color: 'red' }}>{this.state.nameerror}</div> : null}

                                            <div className="tcm-error-message"></div>
                                            <input id="tcm-guest-email" className="form-input" type="text" name="email" placeholder="Email" onChange={(e) => this.handleChange(e)} value={this.state.email} />

                                            <button className="save-btn tcm-truncate tcm-transparent tcm-border-color-ac-h" id="submit-comment" data-parent="0" data-level="0" type="submit" onClick={(e) => this.handleleSubmit(e)}>
                                                Submit comment
                                        </button>
                                            <ToastContainer autoClose={1500} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Grid>
                        <Grid item xs={1} sm={1}></Grid>
                    </Grid>
                </Paper>
                {/* //show comment  */}

                {
                    this.state.isLoaded ?
                        this.state.getdata.comments.map((data, i) => {
                            return (
                                <Paper style={{ marginTop: '1rem' }} key={i}>
                                    <Grid item xs={12} sm={12} md={12} xl={12} lg={12}>
                                        <Grid container>
                                            <Grid item xs={2} sm={2} md={2} xl={1} lg={1}>
                                                <div className="user_img_bk">
                                                    <i className="material-icons person">person</i>
                                                </div>
                                            </Grid>
                                            <Grid item xs={10} sm={10} md={10} xl={11} lg={11}>
                                                <div className="comment-individual">
                                                    <h5>{data.user}</h5>
                                                    <p>{data.message}</p>
                                                </div>
                                            </Grid>
                                        </Grid>

                                    </Grid>

                                </Paper>

                            )
                        }) : <p>Loading...</p>
                }

            </div >
        )
    }
}
