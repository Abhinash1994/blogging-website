import React, { Component } from "react";
import { Grid } from "@material-ui/core";
import "./info.css";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import Highlight from "react-highlight";
import MetaTags from "react-meta-tags";
import CommentFile from "../commentfile";

import API from "../../api";

export default class Blogdetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: "",
      loading: false,
    };
  }
  formatDate(date) {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;
    return [year, month, day].join("-");
  }

  componentDidMount() {
    let url = window.location.href.split("/");
    var lastSegment = url.pop() || url.pop();
    new API()
      .getHttpClient()
      .post("/article/slug", { slug: lastSegment })
      .then((res) => {
        this.setState({ loading: false, list: res.data });
      })
      .catch((error) => {
        console.log(error);
      });
  }
  render() {
    let prop = this.state.list.data;
    return (
      <div>
        {prop ? (
          <Grid container>
            <Grid item lg={2} xl={3}></Grid>
            <Grid
              item
              xs={12}
              sm={12}
              md={12}
              lg={8}
              xl={6}
              className="singlepost"
            >
              <div className="post_header_title">
                <span>
                  <span>
                    <Link to="/">Abhinashkumar</Link> &gt;&gt;{" "}
                    <span>
                      FullStack &gt;&gt;{" "}
                      <span className="breadcrumb_last" aria-current="page">
                        {prop.type ? prop.type : ""}
                      </span>
                    </span>
                  </span>
                </span>
              </div>

              <div className="entrycategories">
                <h5> {prop.type}</h5>
              </div>

              <div className="entry-header">
                <h1 className="entry-title">{prop.title}</h1>
                <p className="entry-meta">
                  <span className="entry-time">
                    {this.formatDate(prop.createdAt)}
                  </span>
                  <span className="entry-author">
                    <Link to="/" className="entry-author-link" rel="author">
                      <span className="entry-author-name">{prop.author}</span>
                    </Link>
                  </span>
                  <span className="entry-comments-link">
                    <Link to="/">1 Comment</Link>
                  </span>
                </p>
              </div>

              <div className="bigInt">{prop.sortdesc} </div>
              <br />

              <div className="cen"></div>
              <br />

              {prop.videourl ? (
                <div className="resp-container">
                  {/* <h4 style={{ fontWeight: 'bold' }}>Video Tutorial</h4><br /> */}
                  <iframe
                    className="resp-iframe"
                    src={prop.videourl}
                    gesture="media"
                    allow="encrypted-media"
                    allowFullScreen
                  ></iframe>
                </div>
              ) : (
                ""
              )}
              <br />
              <br />

              <div className="bigInt">
                <EditorPreview paragraph={prop.description} />{" "}
              </div>
              <br />
              {/* {prop.codedisplay.map((data, i) => (
                <div className="display_code" key={i}>
                  <h3>
                    <b>{data.filename}</b>
                  </h3>
                  <p>{data.paragraph}</p>
                  <div>
                    <Highlight language="javascript">{data.code}</Highlight>
                  </div>
                </div>
              ))} */}
              <div>{/* <CommentFile state={prop} /> */}</div>
            </Grid>
            <Grid item lg={2} xl={3}></Grid>
            <MetaTags>
              <link rel="canonical" href={window.location.href} />
              <title>{prop.title}</title>
              <meta name="description" content={prop.description} />
              <meta name="keywords" content={prop.keyword} />
              <meta property="og:title" content="website" />
            </MetaTags>
          </Grid>
        ) : (
          <p>Loading... </p>
        )}
      </div>
    );
  }
}

class EditorPreview extends Component {
  render() {
    return (
      <div className="editor-preview">
        <div dangerouslySetInnerHTML={{ __html: this.props.paragraph }}></div>
      </div>
    );
  }
}

EditorPreview.defaultProps = {
  paragraph: "",
};

EditorPreview.propTypes = {
  paragraph: PropTypes.string,
};
