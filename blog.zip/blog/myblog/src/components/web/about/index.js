import React, { Component } from 'react'
import { Grid, Paper } from '@material-ui/core';

export default class About extends Component {
    render() {
        return (
            <div>
                <Grid container>
                    <Grid item  md={2} xl={2} lg={2}></Grid>
                    <Grid item xs={12} sm={12} md={8} xl={8} lg={8} id="av_about">
                        <Paper>
                            <div className="main_about">
                                <h1>About Me</h1>
                            </div>
                            <div className="av_paragraph_about">
                                <p>
                                    Hi, This is "Abhinash kumar pandit" & my real name is "Bechu kumar pandit". This is big question for me why i changed my name cause i want know about my another name from my work . I am from Nepal . I have done B.Tech from Sharda University in Greater Noida,G.B.Nagar,Delhi,India . When i was in college, I don't have any idea about Blogging & coding . How to do but when i was in 2nd Year then i was doing codeing . Really, I love it but sometimes you can realize . It's not exciting work cause when you are doing programming then you don't have any idea about time . It will take too much time so first love your work then do. <br/>
                                </p>
                                <p>
                                    Now, I was in lastyear(2018) then so many companies came for placement but i didn't get job . This is main fact for me & i asked question myself . But i can realize if i want job then first focus on "Data Structure" & main core subject . But again didn't get job. Then, I came our country Nepal & few month i spent time with my family again i went to Delhi & gave interview so many company. One day, I got job in "React developer" in Okhla,phase-3. since, 7month I was doing job in react developer & i was preparing Nodejs developement. This is not only few month but I took to much time for <b>"Backend Developer"</b> . After 7th month I was searching job in <b>"Nodejs"</b> . & few days later i got job in "Backend Developement" .
                                </p>
                                <p>
                                    Actually, I was not happy from frontend developement cause always doing samething but i want to love new technology so i came in Backend Developement. Howerver, I am doing job in Backend developement in Noida-63 . This is "cyber security company" . We should provide software for security. & I am doing so many project in <b>"MERN stack developement"</b>.  
                                </p>
                                <p><b>Thank you so much for giving time for read article.</b></p>
                            </div>
                        </Paper>
                    </Grid>
                    <Grid item  md={2} xl={2} lg={2}></Grid>
                </Grid>
            </div>
        )
    }
}
