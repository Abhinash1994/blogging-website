import React, { Component } from 'react'
import './header.css';
import abhinashkumar from './abhinashkumar.png';
import { Grid } from '@material-ui/core/';
import { Link } from 'react-router-dom';
import NavPopUp from '../home/popup';
export default class header extends Component {
    render() {
        return (
            <div className="header">
                <Grid container>
                    <Grid item xs={2} sm={2} md={3} lg={5} xl={5} style={{ textAlign: 'center'}}>
                        <img src={abhinashkumar} alt="abhinashkumar" className="lazyloaded" style={{height:'3.7rem'}}/>
                    </Grid>
                    <Grid item xs={10} sm={10} md={9} lg={7} xl={7}>
                        <nav className="nav-primary" aria-label="Main" id="genesis-nav-primary">
                            {/* <div className="wrap">
                                <ul id="menu-navbar2" className="menu genesis-nav-menu menu-primary js-superfish sf-js-enabled sf-arrows" style={{ touchAction: 'pan-y' }}>
                                    <li id="menu-item-297287" className="smllc-menu-desktop-new-articles menu-item menu-item-type-custom menu-item-object-custom menu-item-297287"><Link to="/"><span>Home</span></Link>
                                    </li>
                                    <li id="menu-item-297287" className="smllc-menu-desktop-new-articles menu-item menu-item-type-custom menu-item-object-custom menu-item-297287"><Link to="/"><span>New Articles</span></Link>
                                    </li>
                                    <li id="menu-item-297306" className="menu-item menu-item-type-custom menu-item-object-custom menu-item-297306"><Link to={"/about"}><span>About</span></Link>
                                    </li>
                                    <li id="menu-item-280890" className="menu-item menu-item-type-custom menu-item-object-custom menu-item-280890"><Link to={"/questions"}><span>Start a blog</span></Link>
                                    </li>
                                    <li id="menu-item-297302" className="menu-item menu-item-type-post_type menu-item-object-page menu-item-297302"><Link to={"/all/questions"}><span>Ask me Question</span></Link></li>
                                </ul>
                            </div> */}
                            <NavPopUp />
                        </nav>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                        <div className="wrap-menu">
                            <ul>
                                
                                <li className="javascript"><Link to="/"><span>Home</span></Link></li>
                                <li className="javascript"><Link to={"/search/javascript"}><span>Javascript</span></Link></li>
                                <li className="javascript"><Link to={"/search/reactjs"}><span>Reactjs</span></Link></li>
                                <li className="javascript"><Link to={"/search/nodejs"}><span>Nodejs</span></Link></li>
                                <li className="javascript"><Link to={"/all/questions"}><span>Ask me Question</span></Link></li>
                                <li className="javascript"><Link to={"/about"}><span>About</span></Link></li>
                            </ul>
                        </div>
                    </Grid>
                </Grid>
            </div>
        )
    }
}
