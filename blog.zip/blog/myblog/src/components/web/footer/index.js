import React, { Component } from "react";
import { Link } from 'react-router-dom';
import { Button } from '@material-ui/core/';
import './footer.css';
class Footer extends Component {
    render() {

        return (

            <section id="footer">
                <div className="container">
                    <div className="row text-center text-xs-center text-sm-left text-md-left">
                        <div className="col-xs-12 col-sm-4 col-md-4">
                            <h5>Quick links</h5>
                            <ul className="list-unstyled quick-links">
                                <li><Link to="/"><i className="fa fa-angle-double-right"></i>Home</Link></li>
                                <li><Link to="/about"><i className="fa fa-angle-double-right"></i>About</Link></li>
                                {/* <li><Link to="/"><i className="fa fa-angle-double-right"></i>FAQ</Link></li> */}
                                {/* <li><Link to="/"><i className="fa fa-angle-double-right"></i>Get Started</Link></li>
                                <li><Link to="/"><i className="fa fa-angle-double-right"></i>Videos</Link></li> */}
                            </ul>
                        </div>
                        <div className="col-xs-12 col-sm-4 col-md-3">
                            <h5>Categories</h5>
                            <ul className="list-unstyled quick-links">
                                <li><Link to="/search/javascript"><i className="fa fa-angle-double-right"></i>Javascript</Link></li>
                                <li><Link to="/search/reactjs"><i className="fa fa-angle-double-right"></i>Reactjs</Link>
                                </li>
                                {/* <li><Link to="/search/mongodb"><i className="fa fa-angle-double-right"></i>Mongodb</Link></li> */}
                                <li><Link to="/search/nodejs"><i className="fa fa-angle-double-right"></i>Nodejs</Link></li>
                                {/* <li><Link to="/search/video"><i className="fa fa-angle-double-right"></i>Tutorial</Link></li> */}
                            </ul>
                        </div>
                        <div className="col-xs-12 col-sm-4 col-md-5">
                            <h5>Subscribe to Blog via Email</h5>
                            <ul className="list-unstyled quick-links">
                                <li style={{ color: '#fff' }}>Want to Learn programming then follow us</li>
                                <li style={{ color: '#fff', textAlign: 'justify' }}>Receive all our future posts instantly in your inbox. Enter your email to enroll.</li>

                            </ul>
                            <div className="footer-subscriber">
                                <input type="email" name="email" required="required" className="subscribe-field-blog_subscription-4" placeholder="Email Address" />
                                <Button variant="contained" color="secondary" className="submitEmail"> Subscribe </Button>
                            </div>


                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
                            <ul className="list-unstyled list-inline social text-center">
                                <li className="list-inline-item"><a href="https://www.facebook.com/byondtechz/"><i className="fa fa-facebook"></i></a></li>
                                {/* <li className="list-inline-item"><Link to="/"><i className="fa fa-linkedin-in" style={{background:'yellow'}}></i></Link></li> */}
                            </ul>
                        </div>

                    </div>
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                            <p> Abhinash kumar @ 2019 <Link to="/" className="linkwebsite">abhinashkumar.com</Link> Made in Nepal.</p>
                            <p className="h6">@ All rights reserved the content is copyrighted to Abhinash kumar pandit </p>
                        </div>
                        <hr />
                    </div>
                </div>
            </section>

        );
    }
}

export default Footer;